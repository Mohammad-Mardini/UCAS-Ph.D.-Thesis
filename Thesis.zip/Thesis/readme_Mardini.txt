

These instructions are made to Mac users, whom using TexShop, other operating systems are by their own.

How to compile UCAS thesis


1- Download or clone our repository.
2- We catogrized our thesis' files into four folders:
	A- Bibliography (contains bibliography files and style)
	B- Img (contains images)
	C- Style (contains UCAS thesis style)
	D- Tex (contains tex files)

3- Tex folder contains two essential files (please don't delete them. ONLY EDIT!!!!) and none essential ones (e.g., introduction). The essential files are 
	A- Front_information generates general information such as names, thesis title ...etc
	B- Front_matter generates abstracts in both English and Chinese languages. 
